# Car Rental App

A simple Node.js + Express + MySQL + Pug web app for managing car rentals.

### Setup
```bash
npm install
npm run dev
