import { pool } from "./config/dbConfig.js";
export { pool };
